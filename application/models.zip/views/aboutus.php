<?php require("header.php");?><!--php required header-->
<div class="jobcategorysinglejob"><!-- country category start-->

<div class="grid-containerabout">
    
 <div href="#" class="grid-itemsinglejob" style="text-align: left;">
<h5 style=" color:grey; text-transform: capitalize; color:#379683; font-size: 1.25rem; font-weight: 500;  padding: 10px 0px 0px 0px; ">
        
       About Us
        </h5>    
        
      
      <div style="display :block; font-weight: 400;font-size: 1rem; text-align:justify ; padding: 10px 0px;  color:#05386b;">
        Rizqdoor.com is the leading marketplace for job seekers and employers. We help employers to find and hire the best candidates for their jobs. We also help job seekers in finding the right job that matches their skill-set. Everyday, numerous job vacancies are listed on rizqdoor.com from top employers.


</div>
<h5 style=" color:grey; text-transform: capitalize; color:#379683; font-size: 1.25rem; font-weight: 500;  padding: 10px 0px 0px 0px; ">
        
     Vision
        </h5>    
        
      
      <div style="display :block; font-weight: 400;font-size: 1rem; text-align:justify ; padding: 10px 0px;  color:#05386b;">
        To be an internationally recognized employment site that is respected and trusted by job seekers and employers alike. 


</div>
<h5 style=" color:grey; text-transform: capitalize; color:#379683; font-size: 1.25rem; font-weight: 500;  padding: 10px 0px 0px 0px; ">
     Mission
        </h5>    
        
      
      <div style="display :block; font-weight: 400;font-size: 1rem; text-align:justify ; padding: 10px 0px;  color:#05386b;">
        Our mission is to be the global leader in online recruitment promotion by helping job seekers and employers find their best fit, as efficiently, conveniently and economically, as possible.


</div>

<h5 style=" color:grey; text-transform: capitalize; color:#379683; font-size: 1.25rem; font-weight: 500;  padding: 10px 0px 0px 0px; ">
     Our Core Values
        </h5>    
        
      
      <div style="display :block; font-weight: 400;font-size: 1rem; text-align:justify ; padding: 10px 0px;  color:#05386b;">
    
<ul>
    <li>Commitment</li>
    <li>Open-mindedness</li>
    <li>Reliability</li>
    <li>Trust</li>
    <li>Consistency</li>
    <li>Honesty</li>
    <li>Innovation</li>
    <li>Positivity</li>
    <li>Respect</li>
    <li>Service to others</li>
</ul>

</div>
</div>


 

</div>

</div>


<?php require("footer.php");?><!--php required footer-->