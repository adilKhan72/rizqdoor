<div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link"style="color: #05386b" href="<?= base_url(''); ?>">
                  Home Page
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= base_url('blog/admin_dashboard'); ?>">

                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= base_url('blog/postblog'); ?>">

                  Post A Blog
                </a>
              </li>
              
            </ul>
          </div>
        </nav>