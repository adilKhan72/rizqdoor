<div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="<?= base_url(''); ?>">
                  Home Page
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="<?php if($page == "Dashboard"){echo 'color:#28a745;';}?>"  href="<?= base_url('users/dashboard'); ?>">

                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="<?php if($page == "custom"){echo 'color:#28a745;';}?>"  href="<?= base_url('users/dashboard'); ?>">

                  custom link
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="<?php if($page == "custom"){echo 'color:#28a745;';}?>"  href="<?= base_url('users/dashboard'); ?>">
                  custom link
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="<?php if($page == "custom"){echo 'color:#28a745;';}?>"  href="<?= base_url('users/dashboard'); ?>">
                 custom link
                </a>
              </li>
               
            </ul>
          </div>
        </nav>