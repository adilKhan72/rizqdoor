<?php require("header.php");?><!--php required header-->

<?php $page = "Dashboard"; require("sidebarnav.php");?><!--php required header-->
        <main  class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3  border-bottom" style="background-color:#53BD6D;padding-top: .4rem; padding-bottom: 0rem; margin-top:10px; border-radius:5px; padding: 0px 10px; color:white;">
              
            <h3 class="h4"><?= $data1->name?>

            </h3>
            <?php
               
             if($loginsuccess = $this->session->flashdata('loginsuccess')){
                ?><div class="alert alert-success" style="margin-bottom: .3rem;">
  <strong>Success!</strong>
<?php
                echo $loginsuccess;
                ?></div><?php
             }
              ?>
          </div>     
          <div class="container">
  <div class="row">
      
          <div class="col-lg" style="background-color:#edf5e1; margin:10px; padding:5px; border-radius:5px; margin-bottom:20px;">
     <div class="text-center  display-4" style="font-size:2em; padding: 5px 0px"> user details </div>
     <?php 
        if(count($data1)){
     ?>
    <table class="table table-hover">
  <thead class="text-center">
    <tr>
      <th scope="col">email</th>
      <th scope="col"><?= $data1->email?></th>
    </tr>
    <tr>
      <th scope="col" colspan="2">experience<br>
      <p style="font-weight:400; padding-top:5px; text-align: center;"><?= $data1->experience?> years</p>
      </th>
    </tr>
    <tr>
      <th scope="col">dateofbirth</th>
      <th scope="col"><?= $data1->dateofbirth?></th>
    </tr>
    <tr>
      <th scope="col">gender</th>
      <th scope="col"><?= $data1->gender?></th>
    </tr>
    <tr>
      <th scope="col"> Country Code: +<?= $data1->countrycode?> </th>
      <th scope="col">Company Phone: <?= $data1->mobilenumber?></th>
    </tr>
    <tr>
        <th scope="col" colspan="2">nationality <br>
      <p style="font-weight:400; padding-top:5px;"><?= $data1->nationality?></p>
    </tr>
    <tr><th colspan="2">
   
<a href="<?= base_url('employer/editcompanydetails');?>" type="button"  class="btn btn-success btn-block"  style="color:white; font-weight:bold;">Edit users details</a>
</th>
</tr>
</thead>
</table>
<?php ;} ?>
</div>
</div>
</div>
        </main>

      </div>
    </div>
<?php require("footer.php");?>
<!--php required footer-->