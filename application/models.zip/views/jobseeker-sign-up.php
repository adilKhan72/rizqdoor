

<?php require("header.php");?><!--php required header-->
<div class="main-div jobcategory"><!--country category start-->
  <div class="main-login">
    <h1 class="country " style="padding-bottom:20px; ">Create a Free Account!</h1>
    <p class="afterheading">Already have an Account?
     <a href="login.php">Log In!</a></p>
     <div class="formdiv">
     <form action="">
     
      <input type="text" id="fname" name="firstname" placeholder="First Name">

 <input type="text" id="fname" name="firstname" placeholder="Last Name">

 <input type="text" id="fname" name="firstname" placeholder="Your email (You@Example.com)">

      <input type="password" id="lname" name="lastname" placeholder="Your Password">

 <input type="text" id="fname" name="firstname" placeholder="Target Job Title">

<select>
    <option value="0"disabled selected>Which field do you want to work in ? </option>
    <option value="1">Audi</option>
    <option value="2">BMW</option>
    <option value="3">Citroen</option>
    <option value="4">Ford</option>
    <option value="5">Honda</option>
    <option value="6">Jaguar</option>
    <option value="7">Land Rover</option>
    <option value="8">Mercedes</option>
    <option value="9">Mini</option>
    <option value="10">Nissan</option>
    <option value="11">Toyota</option>
    <option value="12">Volvo</option>
  </select>

<input type="file" name="file-7[]" id="file-7" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple />
          <label for="file-7"><span>
            
          </span> 
            <strong>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
              </svg> 
            <i style="font-weight: 500; font-style: normal;">Upload your Resume&hellip;</i>
          </strong>
        </label>


<label class="container">Make my Profile Visible to increase my visibilty to employers.
  <input type="checkbox" checked="checked">
  <span class="checkmark"></span>
</label>


      <input type="submit" value="Sign Up!">

      <p style="font-weight: 600; font-size: 1.3em; text-align: center;color: #05386b; padding-bottom: 15px;">OR</p>

      <div class="social-login"><a class="soc-href" href=""><i class="customico-facebook"></i>Login with Facebook</a></div>

      <div class="social-login"><a  class="soc-href" href="" style="background-color: rgb(0,119,181);"><i class="customico-linkedin"></i>Login with LinkediIn</a></div>
      <p class="formendtxt">
        RizqDoor.com never shares any of your activities through Facebook or Google without your explicit permission.
      </p>
      <p class="formendtxt" style="color:#05386b; font-weight: 500;">
        * This option takes effect only for job seekers.
      </p>
    </form>
  </div>
  </div>
</div>
<?php require("footer.php");?><!--php required footer-->
