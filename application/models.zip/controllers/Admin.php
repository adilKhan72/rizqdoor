<?php
class Admin extends CI_Controller {
	
	public function index()
	{
		echo'public index admin';
	}
}